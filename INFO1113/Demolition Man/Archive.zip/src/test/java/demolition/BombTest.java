package demolition;

import org.junit.jupiter.api.Test;
import processing.core.PApplet;

import static org.junit.jupiter.api.Assertions.*;

public class BombTest {

    @Test
    public void bombKillsBombguy() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);

//      Bombguy should move down

        //        press space
        app.draw();
        app.key = ' ';
        app.keyPressed();
        app.keyReleased();

//      Bombguy should place 1 bomb
        for(int i = 0; i <= 360; i++){
            app.draw();
        }
        assertEquals(2, app.lives);
    }

    @Test
    public void bombsMany() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);

//      Bombguy should move down

        app.bombGuy.i = 10;
        app.bombGuy.j = 13;
        app.keyPressed();
        app.key = ' ';
        app.keyReleased();
        app.draw();
        app.delay(1000);

        app.bombGuy.i = 5;
        app.bombGuy.j = 9;
        app.keyPressed();
        app.key = ' ';
        app.keyReleased();
        app.draw();
        app.delay(1000);

        app.bombGuy.i = 1;
        app.bombGuy.j = 1;

        for (int i = 0; i <= 300; i ++){
            app.draw();
            app.delay(10);
        }

    }

}
