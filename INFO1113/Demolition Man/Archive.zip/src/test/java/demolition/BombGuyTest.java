package demolition;
import org.junit.jupiter.api.Test;
import processing.core.PApplet;

import static org.junit.jupiter.api.Assertions.*;

public class BombGuyTest {

    @Test
    public void BombguyWin() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);

//      Bombguy should move down

        //        press space

//      Bombguy should place 1 bomb
        assertEquals(1, app.currentLevel);

        app.draw();
        app.delay(1000);

        app.bombGuy.i = 11;
        app.bombGuy.j = 13;
//        enter next level
        app.draw();
        app.delay(1000);
        app.draw();
        app.delay(1000);

        assertEquals(2, app.currentLevel);

        app.bombGuy.i = 6;
        app.bombGuy.j = 13;
        //        touch goal block
        app.draw();
        app.delay(1000);
        app.draw();
        app.delay(1000);

        assertFalse(app.stillPlaying);
    }

    @Test
    public void BombguyKilledByRed() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[]{"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);

//      Bombguy should move down

        //        press space

//      Bombguy should place 1 bomb
        app.draw();
        app.delay(1000);

        app.bombGuy.i = 5;
        app.bombGuy.j = 8;

        app.draw();

        app.delay(1000);
        assertEquals(2, app.lives);
    }

    @Test
    public void BombguyKilledByYellow() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[]{"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);

//      Bombguy should move down

        //        press space

//      Bombguy should place 1 bomb

        app.bombGuy.i = 9;
        app.bombGuy.j = 5;

        app.draw();
        app.delay(1000);


        assertEquals(2, app.lives);
        System.out.println(app.lives);
    }

    @Test
    public void enemyMoving() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[]{"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);

//      Bombguy should move down

        //        press space

//      Bombguy should place 1 bomb

        app.bombGuy.i = 9;
        app.bombGuy.j = 5;

        for (int i = 0; i <= 1800; i++){
            app.draw();

        }
        assertTrue( app.stillPlaying);
    }

}
