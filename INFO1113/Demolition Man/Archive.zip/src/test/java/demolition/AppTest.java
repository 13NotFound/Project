package demolition;

import processing.core.*;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AppTest {

    @Test
//    T1
    public void frameTest() {
        assertEquals(480, App.WIDTH);
        assertEquals(480, App.HEIGHT);
        assertEquals(60, App.FPS);
    }
    @Test
//    T2
    public void mapFileTest() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);
        assertEquals("level1.txt", app.mapFileName);
        //test the level
        assertEquals(180, app.time);

        assertEquals(3, app.lives);

    }

//    T3
    @Test
    public void restart() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);
        assertEquals(180, app.displayTime);

        for(int i = 0; i <= 180; i++){
            app.draw();
        }
        assertEquals(177, app.displayTime);

        //        after 180 frame (3 seconds)
        app.restart = true;
        app.draw();
        app.delay(1000);

        assertEquals(180, app.displayTime);
//
    }

//T4
    @Test
    public void displayTimeTest() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);
        assertEquals(180, app.displayTime);

        for(int i = 0; i <= 60; i++){
            app.draw();
        }
//        after 60 frame (1 seconds)
        assertEquals(179, app.displayTime);
//
    }
//T5
   @Test
    public void winCheck() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);
        for(int i = 0; i <= 180; i++){
            app.draw();
        }
//        after 180 frame (3 seconds)
        assertEquals(177, app.displayTime);
        app.goal = true;
        for(int i = 0; i <= 180; i++){
            app.draw();
        }
//        after 180 frame (3 seconds)
        assertEquals(177, app.displayTime);
        app.goal = true;
        for(int i = 0; i <= 180; i++){
            app.draw();
        }
        assertEquals(177, app.displayTime);

//        after two wining, time should stay the same

    }
//T6
    @Test
    public void loseCheck() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);
        for(int i = 0; i <= 180; i++){
            app.draw();
        }
//        after 180 frame (3 seconds)
        assertEquals(177, app.displayTime);
        app.stillPlaying = false;
        for(int i = 0; i <= 180; i++){
            app.draw();
        }
//        after 180 frame (3 seconds)
        assertEquals(177, app.displayTime);
//        after lose, time should stay the same

    }
//T7
    @Test
    public void keyTest() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);


        //      Bombguy orignial position

        assertEquals(app.bombGuy.j, 1);
        assertEquals(app.bombGuy.i, 1);

        //        press down key


        app.keyCode = app.DOWN;
        app.keyPressed();
        app.keyReleased();


//      Bombguy should move down

        for(int i = 0; i <= 60; i++){
            app.draw();
        }
        assertEquals(MovingObject.Direction.DOWN, app.bombGuy.direction);
//
        assertEquals(app.bombGuy.j, 1);
        assertEquals(app.bombGuy.i, 2);

//        press up key
        app.keyCode = app.UP;
        app.keyPressed();
        app.keyReleased();


//      Bombguy should move UP

        for(int i = 0; i <= 60; i++){
            app.draw();
        }
        assertEquals(MovingObject.Direction.UP, app.bombGuy.direction);
//
        assertEquals(app.bombGuy.j, 1);
        assertEquals(app.bombGuy.i, 1);

        //        press right key
        app.keyCode = app.RIGHT;
        app.keyPressed();
        app.keyReleased();

//      Bombguy should move Right

        for(int i = 0; i <= 60; i++){
            app.draw();
        }
        assertEquals(MovingObject.Direction.RIGHT, app.bombGuy.direction);
//
        assertEquals(app.bombGuy.j, 2);
        assertEquals(app.bombGuy.i, 1);

        //        press right key

        app.keyCode = app.LEFT;
        app.keyPressed();
        app.keyReleased();

//      Bombguy should move Right

        for(int i = 0; i <= 60; i++){
            app.draw();
        }
        assertEquals(MovingObject.Direction.LEFT, app.bombGuy.direction);
//
        assertEquals(app.bombGuy.j, 1);
        assertEquals(app.bombGuy.i, 1);


        //        press space
        app.key = ' ';
        app.keyPressed();
        app.keyReleased();

//      Bombguy should place 1 bomb
        for(int i = 0; i <= 30; i++){
            app.draw();
        }
        assertEquals(1, app.bombGuy.bombs.size());

    }
    @Test
    public void timeOutLoseCheck() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);
        for(int i = 0; i <= 10801; i++){
            app.draw();
        }
//        after 180 frame (3 seconds)
        System.out.println(app.displayTime);
        assertFalse(app.stillPlaying);
//        after lose, time should stay the same

    }
}
