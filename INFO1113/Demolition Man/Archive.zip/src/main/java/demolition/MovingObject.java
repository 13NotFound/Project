package demolition;

import processing.core.PImage;

import java.util.List;

public abstract class MovingObject {

    protected final Map map;
    protected Direction direction;
    protected int j;
    protected int i;
    protected int frame = 0;
    protected boolean stillAlive;

    protected enum Direction {
        LEFT,
        RIGHT,
        UP,
        DOWN,
    }

    /**
     * construct the MovingObject class
     * @param  map  current map, for objetc coordinate
     */
    public MovingObject(Map map){
        this.stillAlive = true;
        this.map = map;
        this.direction = Direction.DOWN;
    }

    protected int[] coordinateToBombBuyDisplay() {
        int y = i * 32 + 64 - 16;// - 16 to align the top
        int x = j * 32;
        int[] displayCoordinate = new int[2];
        displayCoordinate[0] = x;
        displayCoordinate[1] = y;
        return displayCoordinate;
    }

    protected void draw(App app) {
    }
    protected void tick(App app) {
    }

    protected boolean canMove() {
        switch (direction) {
            case DOWN:
                if (this.map.grid[i + 1][j] != 'W' && this.map.grid[i + 1][j] != 'B') return true;
                break;
            case UP:
                if (this.map.grid[i - 1][j] != 'W' && this.map.grid[i - 1][j] != 'B') return true;
                break;
            case LEFT:
                if (this.map.grid[i][j - 1] != 'W' && this.map.grid[i][j - 1] != 'B') return true;
                break;
            case RIGHT:
                if (this.map.grid[i][j + 1] != 'W' && this.map.grid[i][j + 1] != 'B') return true;
                break;
        }
        return false;
    }

    protected void rightSide() {
        direction = Direction.RIGHT;
        if (canMove()) {
            this.j += 1;
        }
    }


    protected void leftSide() {
        direction = Direction.LEFT;
        if (canMove()) {
            this.j -= 1;
        }
    }

    protected void upSide() {
        direction = Direction.UP;
        if (canMove()) {
            this.i -= 1;
        }
    }

    protected void downSide() {
        direction = Direction.DOWN;
        if (canMove()) {
            this.i += 1;
        }
    }

    /**
     * display the image according to its current direction
     * @param  up  list of object facing up
     * @param  down  list of object facing down
     * @param  left  list of object facing left
     * @param  right  list of object facing up

     * @param  app  App class to access image
     */
    public void displayImage(List<PImage> up, List<PImage> down, List<PImage> left, List<PImage> right, App app){
        int imageIndex = Math.floorDiv(frame, 15);
        PImage displayImage = null;
        switch (this.direction) {
            case UP:
                displayImage = up.get(imageIndex);
                break;
            case DOWN:
                displayImage = down.get(imageIndex);
                break;
            case LEFT:
                displayImage = left.get(imageIndex);
                break;
            case RIGHT:
                displayImage = right.get(imageIndex);
                break;
        }
        int[] displayCoordinate = coordinateToBombBuyDisplay();
        app.image(displayImage, displayCoordinate[0], displayCoordinate[1]);
    }

    protected void goStraight(){
        switch (this.direction) {
            case DOWN:
                this.downSide();
                break;
            case UP:
                this.upSide();
                break;
            case LEFT:
                this.leftSide();
                break;
            case RIGHT:
                this.rightSide();
                break;
        }
    }

}
