package demolition;

import processing.core.PApplet;
import processing.data.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class App extends PApplet {

    public static final int WIDTH = 480;
    public static final int HEIGHT = 480;
    public static final int FPS = 60;

    public Resource resource;
    public Map map;
    public BombGuy bombGuy;
    public int time;
    public int displayTime;
    public int frame;
    public Bomb bomb;
//    the very first bomb, other bomb will use duplicate of iy
    public String mapFileName;
    public boolean goal = false;
    public boolean restart = false;
    public List<MovingObject> allNPC;
    public List<MovingObject> allObject;

    public boolean send_command = false;

    public int currentLevel = 1;

    public JSONArray levelsData;
    public int lives;

    public boolean stillPlaying = true;

    public App() {
    }

    /**
        read the config file
     * @param  path  the string path of the reading file
     * @param  restart to whether load the life again or not
     */
    public void readConfig(String path, boolean restart){
        try{
            String jsonData = new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
            JSONObject jsonObject = JSONObject.parse(jsonData);

            this.levelsData = (JSONArray) jsonObject.get("levels");

            if(! restart){
                this.lives = (int) jsonObject.get("lives");
            }
        } catch (IOException e){
            e.printStackTrace();
        }

    }

    /**
     * load the map file name and display time to local variable
     * @param  levelsData JsonArray data read by readconfig
     */
    public void loadMap(JSONArray levelsData){
        JSONObject levelInfo = (JSONObject) levelsData.get(currentLevel - 1);
        this.mapFileName = levelInfo.get("path").toString();
        this.time = (int) levelInfo.get("time");
    }

    /**
     * set the window to 480x480
     */
    public void settings() {
        size(WIDTH, HEIGHT);
    }

     /**
     load the time in level data to display time
     <p>
     load font
     <p>
     initialise a list for all npc character
     <p>
     load the npc characters in to local arraylist
     */
    public void setup() {
        frameRate(FPS);
        readConfig("config.json", restart);
        loadMap(this.levelsData);
        this.displayTime = this.time;
        this.textFont(this.createFont("src/main/resources/PressStart2P-Regular.ttf",15));
        this.fill(0,0,0);
        this.resource = new Resource(this);
        this.map = new Map(this.mapFileName, this.resource);
        this.bomb = new Bomb(this.resource, this.map);
        allNPC = new ArrayList<>();
        map.loadNpc(this);
    }

    private void clock(){
        if (stillPlaying) {
            frame += 1;
            if (frame == 60) {
                displayTime--;
                frame = 0;
            }
        }
    }

    /**
     * <p>
     * Main game mechanism:
     * <p>
                * if bombguy touches the goal and there is next level, game enter next level
                * if bombguy touches the goal and it is the last level, game win
                * if time used up or bombguy used all life, game lose
     * <p>
     * Rendering order:
     * <p>
                 * render game object according to y axis (top to bottom)
     */
    public void draw() {
        clock();
        background(239, 129, 0);
        if (restart){
            this.setup();
            restart = false;
        }
        if (goal) {
            this.currentLevel += 1;
            if(this.currentLevel <= this.levelsData.size()){
                goal = false;
                this.setup();
            }
            else{
                this.text("YOU WIN", 180, 240);
                stillPlaying = false;
            }
        } else if (this.lives == 0 || this.displayTime == 0) {
            this.text("GAME OVER", 180, 240);
            stillPlaying = false;
        } else {
            allObject = new ArrayList<>();
            this.map.draw(this);
        }
    }

    /**
     * switch key case to move bombguy up left right down
     */
    public void keyReleased(){
        if (send_command) {
            if (key == ' ') {
                this.bombGuy.putBomb(this.bomb);
            } else if (keyCode == UP) {
                this.bombGuy.upSide();
            } else if (keyCode == DOWN) {
                this.bombGuy.downSide();
            } else if (keyCode == LEFT) {
                this.bombGuy.leftSide();
            } else if (keyCode == RIGHT) {
                this.bombGuy.rightSide();
            }
        }
        send_command = false;
    }

    /**
     * in combination with keyRealeased, means the action will only trigger for each press and release
     (not simply press)
     */
    public void keyPressed() {
        send_command = true;
    }

    public static void main(String[] args) {
        PApplet.main("demolition.App");
    }
}
