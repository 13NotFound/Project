package demolition;

import processing.core.PImage;

import java.util.*;

public class BombGuy extends MovingObject{

    private final List<PImage> left;
    private final List<PImage> right;
    private final List<PImage> up;
    private final List<PImage> down;
    public final ArrayList<MovingObject> bombs;

    /**
     * construct bombguy
     * @param  resource  resource for spirte
     * @param  map  current map
     */
    public BombGuy( Resource resource, Map map) {
        super(map);
        this.direction = Direction.DOWN;
        this.bombs = new ArrayList<>();
        this.left = resource.getLeftP();
        this.right = resource.getRightP();
        this.up = resource.getUpP();
        this.down = resource.getDownP();
        // find it in this.map.grid;
        for (int i = 0; i < super.map.grid.length; i++) {
            for (int j = 0; j < super.map.grid[i].length; j++) {
                if (map.grid[i][j] == 'P') {
                    super.j = j;
                    super.i = i;
                }
            }
        }
    }

    /**
     * draw the image of current direction
     * @param  app PApplet class
     */
    public void draw(App app) {
        int imageIndex = Math.floorDiv(frame, 15);
        PImage displayImage = null;
        switch (super.direction) {
            case UP:
                displayImage = this.up.get(imageIndex);
                break;
            case DOWN:
                displayImage = this.down.get(imageIndex);
                break;
            case LEFT:
                displayImage = this.left.get(imageIndex);
                break;
            case RIGHT:
                displayImage = this.right.get(imageIndex);
                break;
        }
        int[] displayCoordinate = coordinateToBombBuyDisplay();
        app.image(displayImage, displayCoordinate[0], displayCoordinate[1]);
        // draw active bombs
    }

    /**
     * update facing direction and check if bombguy touches the goal
     * @param  app PApplet class
     */
    public void tick(App app) {
        frame += 1;
        if (frame == 60) {
            frame = 0;
        }
        if (reachGoal()) {
            app.goal = true;
        }
    }
    private boolean reachGoal() {
        return this.map.grid[i][j] == 'G';
    }

    /**
     * put a bomb in current location
     * @param  bomb previously constructed bomb
     */
    public void putBomb (Bomb bomb) { // the bomb to copy from
        this.bombs.add(Bomb.aNewBombAtLocation(bomb, i, j));
    }

}