package demolition;
import processing.core.PImage;
import java.util.*;
import java.io.*;
public class Map {
    private final PImage solid;
    private final PImage broken;
    private final PImage empty;
    private final PImage goal;
    private final PImage icon;
    private final PImage clock;
    private static final int TEXT_WIDTH = 15;
    private static final int TEXT_HEIGHT = 13;
    public char[][] grid = new char[TEXT_HEIGHT][TEXT_WIDTH];

    /**
     * construct the map class (and open the map file)
     * @param  mapName  the path of map
     * @param  resource the resource folder
     */
    public Map(String mapName, Resource resource) {

        this.solid = resource.getSolidWall();
        this.broken = resource.getBrokenWall();
        this.empty = resource.getEmpty();
        this.goal = resource.getGoal();
        this.icon = resource.getIcon();
        this.clock = resource.getClock();

        try {
            File readMap = new File(mapName);
            Scanner reader = new Scanner(readMap);
            for (int i = 0; i < TEXT_HEIGHT; i++) {
                String sentence = reader.nextLine();
                for (int j = 0; j < TEXT_WIDTH; j++) {
                    grid[i][j] = sentence.charAt(j);
                }
            }

            reader.close();
        } catch (FileNotFoundException ignored) {
        }
    }

    /**
     * draw the map object, and append all the game object to allObject class and tick and draw them
     * @param  app  App class to use image method
     */
    public void draw(App app) {

        app.image(icon,144,16);
        app.text(app.lives,180,40);
        app.image(clock,272,16);
        app.text(app.displayTime,304,40);


        for (int i = 0; i < TEXT_HEIGHT; i++) {
            for (int j = 0; j < TEXT_WIDTH; j++) {
                int WIDTH = 32;
                int OFFSET = 64;
                if (grid[i][j] == 'W') {
                    app.image(this.solid, WIDTH * j, OFFSET + WIDTH * i);
                }
                else if (grid[i][j] == 'B') {
                    app.image(this.broken, WIDTH * j, OFFSET + WIDTH * i);
                } else if (grid[i][j] == 'G') {
                    app.image(this.goal, WIDTH * j, OFFSET + WIDTH * i);
                }
                else {
                    // initialise as empty space
                    app.image(this.empty, WIDTH * j, OFFSET + WIDTH * i);
                }
            }
        }

        app.allObject.addAll(app.allNPC);
        app.allObject.addAll(app.bombGuy.bombs);

        for(int i = 0; i < 13; i ++){
            for(MovingObject npc: app.allObject){
                if(npc.i == i && npc.stillAlive) {
                    npc.tick(app);
                    npc.draw(app);
                }
            }
        }
        app.allObject.clear();

    }

    /**
     * add all npc to app arraylist
     * @param  app  App class to access all app variable
     */
    public void loadNpc(App app){
        app.allNPC.add(app.bombGuy = new BombGuy( app.resource, app.map));
        for(int i = 0; i < app.map.grid.length ; i ++){
            for(int j = 0; j < app.map.grid[i].length; j ++){
                if(app.map.grid[i][j] == 'Y') {
                    app.allNPC.add(new YellowEnemy(i, j, app.resource, app.map));
                }
                else if(app.map.grid[i][j] == 'R'){
                    app.allNPC.add(new RedEnemy(i, j, app.resource, app.map));
                }
            }
        }

    }
}
