package demolition;

import processing.core.PImage;

import java.util.*;

public class Resource {

    private final PImage icon;
    private final PImage clock;

    private final PImage solidWall;
    private final PImage brokenWall;
    private final PImage empty;
    private final PImage goal;

    private final List<PImage> leftP;
    private final List<PImage> rightP;
    private final List<PImage> upP;
    private final List<PImage> downP;

    private final List<PImage> bombImage;
    private final PImage horizBomb;
    private final PImage vertBomb;
    private final PImage centreBomb;

    private final PImage endBotExplosion;
    private final PImage endLeftExplosion;
    private final PImage endRightExplosion;
    private final PImage endTopExplosion;


    private final List<PImage> leftY;
    private final List<PImage> rightY;
    private final List<PImage> upY;
    private final List<PImage> downY;

    private final List<PImage> leftR;
    private final List<PImage> rightR;
    private final List<PImage> upR;
    private final List<PImage> downR;

    /**
     * @return  PImage icon
     */
    public PImage getIcon() {
        return icon;
    }

    /**
     * @return  PImage clock
     */
    public PImage getClock() {
        return clock;
    }

    /**
     * @return  PImage solidWall
     */
    public PImage getSolidWall(){
        return solidWall;
    }

    /**
     * @return  PImage brokenWall
     */
    public PImage getBrokenWall() {
        return brokenWall;
    }

    /**
     * @return  PImage empty
     */
    public PImage getEmpty() {
        return empty;
    }

    /**
     * @return  PImage goal
     */
    public PImage getGoal() {
        return goal;
    }

    /**
     * @return  PImage leftP
     */
    public List<PImage> getLeftP() {
        return leftP;
    }

    /**
     * @return  PImage rightP
     */
    public List<PImage> getRightP() {
        return rightP;
    }

    /**
     * @return  PImage upP
     */
    public List<PImage> getUpP() {
        return upP;
    }

    /**
     * @return  PImage downP
     */
    public List<PImage> getDownP() {
        return downP;
    }

    /**
     * @return  PImage bombImage
     */
    public List<PImage> getBombImage() {
        return bombImage;
    }

    /**
     * @return  PImage horizBomb
     */
    public PImage getHorizBomb() {
        return horizBomb;
    }

    /**
     * @return  PImage vertBomb
     */
    public PImage getVertBomb() {
        return vertBomb;
    }

    /**
     * @return  PImage centreBomb
     */
    public PImage getCentreBomb() {
        return centreBomb;
    }

    /**
     * @return  PImage leftY
     */
    public List<PImage> getLeftY() {
        return leftY;
    }

    /**
     * @return  PImage rightY
     */
    public List<PImage> getRightY() {
        return rightY;
    }

    /**
     * @return  PImage upY
     */
    public List<PImage> getUpY() {
        return upY;
    }

    /**
     * @return  PImage downY
     */
    public List<PImage> getDownY() {
        return downY;
    }

    /**
     * @return  PImage leftR
     */
    public List<PImage> getLeftR() {
        return leftR;
    }

    /**
     * @return  PImage rightR
     */
    public List<PImage> getRightR() {
        return rightR;
    }

    /**
     * @return  PImage getUpR
     */
    public List<PImage> getUpR() {
        return upR;
    }

    /**
     * @return  PImage downR
     */
    public List<PImage> getDownR() {
        return downR;
    }

    /**
     * @return  PImage endBotExplosion
     */
    public PImage getEndBotExplosion() {
        return endBotExplosion;
    }

    /**
     * @return  PImage endLeftExplosion
     */
    public PImage getEndLeftExplosion() {
        return endLeftExplosion;
    }

    /**
     * @return  PImage endRightExplosion
     */
    public PImage getEndRightExplosion() {
        return endRightExplosion;
    }

    /**
     * @return  PImage endTopExplosion
     */
    public PImage getEndTopExplosion() {
        return endTopExplosion;
    }

    /**
     * @param   app access to loadImage method
     */
    public Resource(App app){
        this.icon = app.loadImage("src/main/resources/icons/player.png");
        this.clock = app.loadImage("src/main/resources/icons/clock.png");

        this.solidWall = app.loadImage("src/main/resources/wall/solid.png");
        this.brokenWall = app.loadImage("src/main/resources/broken/broken.png");
        this.empty = app.loadImage(("src/main/resources/empty/empty.png"));
        this.goal = app.loadImage("src/main/resources/goal/goal.png");


        this.leftP = new ArrayList<PImage>();
        this.leftP.add(app.loadImage("src/main/resources/player/player_left1.png"));
        this.leftP.add(app.loadImage("src/main/resources/player/player_left2.png"));
        this.leftP.add(app.loadImage("src/main/resources/player/player_left3.png"));
        this.leftP.add(app.loadImage("src/main/resources/player/player_left4.png"));

        this.rightP = new ArrayList<PImage>();

        this.rightP.add(app.loadImage("src/main/resources/player/player_right1.png"));
        this.rightP.add(app.loadImage("src/main/resources/player/player_right2.png"));
        this.rightP.add(app.loadImage("src/main/resources/player/player_right3.png"));
        this.rightP.add(app.loadImage("src/main/resources/player/player_right4.png"));

        this.upP = new ArrayList<PImage>();

        this.upP.add(app.loadImage("src/main/resources/player/player_up1.png"));
        this.upP.add(app.loadImage("src/main/resources/player/player_up2.png"));
        this.upP.add(app.loadImage("src/main/resources/player/player_up3.png"));
        this.upP.add(app.loadImage("src/main/resources/player/player_up4.png"));

        this.downP = new ArrayList<PImage>();

        this.downP.add(app.loadImage("src/main/resources/player/player1.png"));
        this.downP.add(app.loadImage("src/main/resources/player/player2.png"));
        this.downP.add(app.loadImage("src/main/resources/player/player3.png"));
        this.downP.add(app.loadImage("src/main/resources/player/player4.png"));

        ///

        this.bombImage = new ArrayList<PImage>();

        this.bombImage.add(app.loadImage("src/main/resources/bomb/bomb.png"));
        this.bombImage.add(app.loadImage("src/main/resources/bomb/bomb1.png"));
        this.bombImage.add(app.loadImage("src/main/resources/bomb/bomb2.png"));
        this.bombImage.add(app.loadImage("src/main/resources/bomb/bomb3.png"));
        this.bombImage.add(app.loadImage("src/main/resources/bomb/bomb4.png"));
        this.bombImage.add(app.loadImage("src/main/resources/bomb/bomb5.png"));
        this.bombImage.add(app.loadImage("src/main/resources/bomb/bomb6.png"));
        this.bombImage.add(app.loadImage("src/main/resources/bomb/bomb7.png"));
        this.bombImage.add(app.loadImage("src/main/resources/bomb/bomb8.png"));

        this.centreBomb = app.loadImage("src/main/resources/explosion/centre.png");
        this.horizBomb = app.loadImage("src/main/resources/explosion/horizontal.png");
        this.vertBomb = app.loadImage("src/main/resources/explosion/vertical.png");

        this.endBotExplosion = app.loadImage("src/main/resources/explosion/end_bottom.png");
        this.endLeftExplosion = app.loadImage("src/main/resources/explosion/end_left.png");
        this.endRightExplosion = app.loadImage("src/main/resources/explosion/end_right.png");
        this.endTopExplosion = app.loadImage("src/main/resources/explosion/end_top.png");

        this.leftY = new ArrayList<PImage>();
        this.leftY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_left1.png"));
        this.leftY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_left2.png"));
        this.leftY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_left3.png"));
        this.leftY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_left4.png"));

        this.rightY = new ArrayList<PImage>();

        this.rightY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_right1.png"));
        this.rightY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_right2.png"));
        this.rightY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_right3.png"));
        this.rightY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_right4.png"));

        this.upY = new ArrayList<PImage>();

        this.upY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_up1.png"));
        this.upY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_up2.png"));
        this.upY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_up3.png"));
        this.upY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_up4.png"));

        this.downY = new ArrayList<PImage>();

        this.downY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_down1.png"));
        this.downY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_down2.png"));
        this.downY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_down3.png"));
        this.downY.add(app.loadImage("src/main/resources/yellow_enemy/yellow_down4.png"));


        this.leftR = new ArrayList<PImage>();
        this.leftR.add(app.loadImage("src/main/resources/red_enemy/red_left1.png"));

        this.leftR.add(app.loadImage("src/main/resources/red_enemy/red_left2.png"));
        this.leftR.add(app.loadImage("src/main/resources/red_enemy/red_left3.png"));
        this.leftR.add(app.loadImage("src/main/resources/red_enemy/red_left4.png"));

        this.rightR = new ArrayList<PImage>();

        this.rightR.add(app.loadImage("src/main/resources/red_enemy/red_right1.png"));
        this.rightR.add(app.loadImage("src/main/resources/red_enemy/red_right2.png"));
        this.rightR.add(app.loadImage("src/main/resources/red_enemy/red_right3.png"));
        this.rightR.add(app.loadImage("src/main/resources/red_enemy/red_right4.png"));

        this.upR = new ArrayList<PImage>();

        this.upR.add(app.loadImage("src/main/resources/red_enemy/red_up1.png"));
        this.upR.add(app.loadImage("src/main/resources/red_enemy/red_up2.png"));
        this.upR.add(app.loadImage("src/main/resources/red_enemy/red_up3.png"));
        this.upR.add(app.loadImage("src/main/resources/red_enemy/red_up4.png"));

        this.downR = new ArrayList<PImage>();

        this.downR.add(app.loadImage("src/main/resources/red_enemy/red_down1.png"));
        this.downR.add(app.loadImage("src/main/resources/red_enemy/red_down2.png"));
        this.downR.add(app.loadImage("src/main/resources/red_enemy/red_down3.png"));
        this.downR.add(app.loadImage("src/main/resources/red_enemy/red_down4.png"));

    }

}
