package demolition;

import processing.core.PImage;
import java.util.*;

public class Bomb extends MovingObject{

    private final List<PImage> bombImages;
    private final PImage horizontal;
    private final PImage vertical;
    private final PImage centre;
    private final PImage endBotExplosion;
    private final PImage endLeftExplosion;
    private final PImage endRightExplosion;
    private final PImage endTopExplosion;
    private final ArrayList<int[]> leftRenderArea = new ArrayList<>();
    private final ArrayList<int[]> rightRenderArea = new ArrayList<>();
    private final ArrayList<int[]> topRenderArea = new ArrayList<>();
    private final ArrayList<int[]> botRenderArea = new ArrayList<>();

    public int j;
    public int i;
    private boolean exploded = false;
    private int countDown = 120;
    private int explosionCountDown = 30;
    private final int[][] bombArea;
    private boolean bombGuyLifeUpdate = false;
    private final Resource resource;

    /**
     * @param  resource  the preloaded resource of images
     * @param  map map for bomb to update its location and render effect
     */
    public Bomb(Resource resource, Map map) {
        super(map);
        this.bombArea = new int[13][15];
        this.bombImages = resource.getBombImage();
        this.resource = resource;
        this.horizontal = resource.getHorizBomb();
        this.vertical = resource.getVertBomb();
        this.centre = resource.getCentreBomb();
        this.endBotExplosion = resource.getEndBotExplosion();
        this.endLeftExplosion = resource.getEndLeftExplosion();
        this.endRightExplosion= resource.getEndRightExplosion();
        this.endTopExplosion = resource.getEndTopExplosion();
    }

    /**
     set bomb current location
     * @param  i  the y axis of bomb
     * @param  j the x axis of bomb
     */
    private void setLocation(int i, int j) {
        this.i = i;
        this.j = j;
    }

    /**
     set a new bomb at location i j
     * @param originalMbomb previous bomb class to replicate from
     * @param  i new bomb y axis
     * @param  j new bomb x axis
     * @return newBomb the new created bomb
     */
    public static Bomb aNewBombAtLocation(Bomb originalMbomb, int i, int j) {
        Bomb newBomb = new Bomb(originalMbomb.resource, originalMbomb.map);
        newBomb.setLocation(i, j);
        return newBomb;
    }

    /**
     render the bomb image according to parameter
     * @param app  the PApplet class to draw in
     * @param renderArea the list of coordinates of render obejct
     * @param end PImage of the end of renderarea
     * @param mid PImage of the mid of renderarea
     */
    public void rendBomb(App app, ArrayList<int[]> renderArea, PImage end, PImage mid){
        for (int i = 0; i < renderArea.size(); i++){
            if (i+1 == renderArea.size()){
                app.image(end, renderArea.get(i)[0], renderArea.get(i)[1]);
            }
            else{
                app.image(mid, renderArea.get(i)[0], renderArea.get(i)[1]);
            }
        }
    }

    /**
     * <p>
     * change the image every 0.25 seconds
     * <p>
     render the explosion area
     * <p>
     restart the map if bomb effect touches bomberguy (and minus his life);
     * @param  app  the PApplet class to draw the bomb effect
     */
    public void draw(App app) {
        if (!super.stillAlive) return;
        //centre coordinate
        int x = 32 * this.j;
        int y = 64 + 32 * this.i;
        if (countDown > 0) {
            int imageIndex = Math.floorDiv(countDown, 15);
            PImage displayImage = this.bombImages.get(8-imageIndex);
            app.image(displayImage, x, y);
            //display the image of the bomb
        }
        else {
            // if the bomb counts to zero
            app.image(this.centre, x, y);
            rendBomb(app, rightRenderArea, this.endRightExplosion, this.horizontal );
            rendBomb(app, leftRenderArea, this.endLeftExplosion, this.horizontal );
            rendBomb(app, topRenderArea, this.endTopExplosion, this.vertical );
            rendBomb(app, botRenderArea, this.endBotExplosion, this.vertical );
            if (bombGuyLifeUpdate){
                app.lives -= 1;
                app.restart = true;
            }
        }
    }

    private boolean recordRenderArea(ArrayList<int[]> renderArea, char[] line, int y, int x, int[] ints, int[] bombarea) {
        if (line[y] == 'W') {
            return true;
        }
        bombarea[x] = 1;
        renderArea.add(ints);

        return line[y] == 'B';
    }

    /**
     * x y coordinates conversion to pixcel coordiantes
     * @param  j  x coordinate
     * @param  i  y coordinate
     * @return displayCoordinate x,y coordinates but in pixcels
     */
    public int[] toXYCoordinate(int j, int i) {
        int y = i * 32 + 64;
        int x = j * 32;
        int[] displayCoordinate = new int[2];
        displayCoordinate[0] = x;
        displayCoordinate[1] = y;
        return displayCoordinate;
    }

    /**
     * update bomb countdown, and calculate explosion area when explode
     * @param  app  App class to draw
     */
    public void tick(App app) {
        if (countDown > 0) {
            countDown -= 1;
        } else {
            explosionCountDown -= 1;
        }
        checkVictims(app);
        if (explosionCountDown == 0 ){
            super.stillAlive = false;
        }
        if (countDown == 0 && !exploded) {

            char[][] grid = app.map.grid;

            this.bombArea[i][j] = 1;

            // draw horizontal  [][]X[][]
            char[] row = grid[i];
            // to left
            for (int m = j-1; m >= Math.max(0, j - 2); m--) {
                // solid wall, ends early.
                if (recordRenderArea(leftRenderArea, row, m, m, toXYCoordinate(m, i), this.bombArea[i])) break;
            }
//            to right
            for (int m = j+1; m <= Math.min(15, j + 2); m++) {
                // solid wall, ends early.

                if (recordRenderArea(rightRenderArea, row, m, m, toXYCoordinate(m, i), this.bombArea[i])) break;

            }
            char[] column = new char[15];

            for (int m = 0; m < 13; m ++){
                column[m] = (grid[m][j]);
            }
            //to top
            for (int m = i-1; m >= Math.max(0, i - 2); m--) {
                if (recordRenderArea(topRenderArea, column, m, j, toXYCoordinate(j, m), this.bombArea[m])) break;

            }

            for (int m = i+1; m <= Math.min(13, i + 2); m++) {
                // solid wall, ends early.
                if (recordRenderArea(botRenderArea, column, m, j, toXYCoordinate(j, m), this.bombArea[m])) break;
            }
            for (int i=0;i<13;i++){
//          this blow up the broken wall
                for(int j = 0;j<15;j++){
                    if (bombArea[i][j]==1 && grid[i][j] != 'G'){
                        grid[i][j] = ' ';
                    }
                }
            }

            exploded = true;
        }
    }
    private void checkVictims(App app){
        if (bombArea[app.bombGuy.i][app.bombGuy.j] == 1){
            bombGuyLifeUpdate = true;
            return;
        }
        for(MovingObject npc : app.allNPC){
            if (bombArea[npc.i][npc.j] == 1){
                npc.stillAlive = false;
            }
        }
    }

}
