package demolition;

import processing.core.PImage;

import java.util.List;
import java.util.Random;


public class RedEnemy extends MovingObject{

    private final List<PImage> left;
    private final List<PImage> right;
    private final List<PImage> up;
    private final List<PImage> down;

    /**
     * construct RedEnemy
     * @param  j  x coordinate
     * @param  i  y coordinate
     * @param  resource  resource for spirte
     * @param  map  current map
     */
    public RedEnemy(int i, int j, Resource resource, Map map) {
        super(map);
        this.direction = Direction.DOWN;
        this.left = resource.getLeftR();
        this.right = resource.getRightR();
        this.up = resource.getUpR();
        this.down = resource.getDownR();
        super.i = i;
        super.j = j;
    }

    /**
     * draw the image of current direction
     * @param  app to access image
     */
    public void draw(App app) {
        super.displayImage(up,down,left,right, app);
    }

    /**
     * update facing direction, confirm if bombguy at their location
     * @param  app to access image
     */
    public void tick(App app) {

        Random rand = new Random(); //instance of random class
        int upperbound = 4;
        //generate random values from 0-24
        int int_random = rand.nextInt(upperbound);

        frame += 1;
        if (frame == 60){
            if (! super.canMove()) {
//                move in straight line if there is no enemy
                switch (int_random) {
                    case 0:
                        super.direction = Direction.LEFT;
                        break;
                    case 1:
                        super.direction = Direction.RIGHT;
                        break;
                    case 2:
                        super.direction = Direction.UP;
                        break;
                    case 3:
                        super.direction = Direction.DOWN;
                        break;
                }
            }
            super.goStraight();
            frame = 0;
        }

        if (app.bombGuy.i == super.i && app.bombGuy.j == super.j){
            app.lives -= 1;
            app.restart = true;
        }
    }

}
