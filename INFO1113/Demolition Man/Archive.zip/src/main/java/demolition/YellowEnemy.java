package demolition;

import processing.core.PImage;
import java.util.*;


public class YellowEnemy extends MovingObject{

    private final List<PImage> left;
    private final List<PImage> right;
    private final List<PImage> up;
    private final List<PImage> down;

    /**
     * construct YellowEnemy
     * @param  j  x coordinate
     * @param  i  y coordinate
     * @param  resource  resource for spirte
     * @param  map  current map
     */
    public YellowEnemy(int i, int j,Resource resource, Map map) {
        super(map);
        this.direction = Direction.DOWN;
        this.left = resource.getLeftY();
        this.right = resource.getRightY();
        this.up = resource.getUpY();
        this.down = resource.getDownY();
        super.i = i;
        super.j = j;
        // find it in this.map.grid;
    }

    /**
     * draw the image of current direction
     * @param  app PApplet class
     */
    public void draw(App app) {
        super.displayImage(up,down,left,right, app);
    }

    /**
     * update facing direction
     * @param  app PApplet class
     */
    public void tick(App app) {
        frame += 1;
        if (frame == 60) {
            if (!super.canMove()) {
                switch (super.direction) {
                    case DOWN:
                        super.direction = Direction.LEFT;
                        break;
                    case UP:
                        super.direction = Direction.RIGHT;

                        break;
                    case LEFT:
                        super.direction = Direction.UP;

                        break;
                    case RIGHT:
                        super.direction = Direction.DOWN;
                        break;
                }
            }
            super.goStraight();
            frame = 0;
        }
        if (app.bombGuy.i == super.i && app.bombGuy.j == super.j) {
            app.lives -= 1;
            app.restart = true;
        }
    }
}