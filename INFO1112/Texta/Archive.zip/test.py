import re
str = "a b cabc"
print(bool(re.search("a b c",str)))