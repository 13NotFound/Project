meow = 0%2
print(meow)