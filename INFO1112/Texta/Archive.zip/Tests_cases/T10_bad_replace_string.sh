#!/bin/bash

cd ..
python3 texta.py ./Tests_cases/T10_cmdfile.in ./Tests_cases/T10_file1.in