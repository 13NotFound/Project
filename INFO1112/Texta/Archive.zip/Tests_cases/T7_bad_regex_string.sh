#!/bin/bash

cd ..
python3 texta.py ./Tests_cases/T7_cmdfile.in ./Tests_cases/T7_file1.in
