#!/bin/bash

cd ..
python3 texta.py ./Tests_cases/T23_cmdfile.in ./Tests_cases/T23_file1.in

