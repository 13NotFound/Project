#!/bin/bash

cd ..
python3 texta.py ./Tests_cases/T4_cmdfile.in ./Tests_cases/T4_file1.in
