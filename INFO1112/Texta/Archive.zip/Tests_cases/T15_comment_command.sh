#!/bin/bash

cd ..
python3 texta.py ./Tests_cases/T15_cmdfile.in ./Tests_cases/T15_file1.in

