#!/bin/bash

cd ..
python3 texta.py ./Tests_cases/T17_cmdfile.in ./Tests_cases/T17_file1.in

