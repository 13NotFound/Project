#!/bin/bash

# shellcheck disable=SC1072
cd ..
python3 texta.py ???
