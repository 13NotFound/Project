#!/bin/bash

# shellcheck disable=SC1072
cd ..
python3 texta.py ./Tests_cases/T2_cmdfile.in ???
