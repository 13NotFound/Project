#!/bin/bash

cd ..
python3 texta.py ./Tests_cases/T18_cmdfile.in ./Tests_cases/T18_file1.in

