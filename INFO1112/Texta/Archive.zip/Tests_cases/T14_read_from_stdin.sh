#!/bin/bash

cd ..
python3 texta.py ./Tests_cases/T14_cmdfile.in

