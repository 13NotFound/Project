#!/bin/bash

cd ..
python3 texta.py ./Tests_cases/T21_cmdfile.in ./Tests_cases/T21_file1.in

