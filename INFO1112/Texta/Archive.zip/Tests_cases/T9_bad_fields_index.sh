#!/bin/bash

cd ..
python3 texta.py ./Tests_cases/T9_cmdfile.in ./Tests_cases/T9_file1.in
